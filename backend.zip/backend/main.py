import asyncio
import io
import subprocess
import sys
import time
import traceback
import zipfile
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from database import async_session, get_db, init_db
from auth import (create_access_token, generate_access_code, generate_session_token,
                      get_current_teacher, hash_password, verify_down_token, verify_password)
from models import AIReview, Grade, Lesson, StudentSession, Submission, Task, Teacher

settings = get_settings()

# ═══════════════════════════ СХЕМЫ ЗАПРОСОВ ═══════════════════════════
class RegisterIn(BaseModel):
    email: str; password: str; full_name: str

class LoginIn(BaseModel):
    email: str; password: str

class LessonIn(BaseModel):
    title: str; description: str = ""; deadline: datetime | None = None

class LessonPatch(BaseModel):
    title: str | None = None; description: str | None = None; is_published: bool | None = None

class TaskIn(BaseModel):
    title: str; description: str = ""; starter_code: str = ""
    ai_criteria: str = ""; ai_system_prompt: str = ""; order_index: int = 1

class TaskPatch(BaseModel):
    title: str | None = None; description: str | None = None; starter_code: str | None = None
    ai_criteria: str | None = None; ai_system_prompt: str | None = None; order_index: int | None = None

class GradeIn(BaseModel):
    score: int = Field(ge=0, le=100); comment: str = ""

class JoinIn(BaseModel):
    access_code: str; surname: str = ""; name: str = ""; group: str = ""; down_token: str | None = None

class CodeIn(BaseModel):
    code: str

# ═══════════════════════════ СЕРИАЛИЗАЦИЯ ═══════════════════════════
def lesson_dict(l: Lesson, tc: int = 0, sc: int = 0) -> dict:
    return {"id": l.id, "title": l.title, "description": l.description or "", "access_code": l.access_code,
            "is_published": bool(l.is_published), "deadline": l.deadline.isoformat() if l.deadline else None,
            "created_at": l.created_at.isoformat() if l.created_at else None, "task_count": tc, "student_count": sc}

def task_dict(t: Task) -> dict:
    return {"id": t.id, "lesson_id": t.lesson_id, "order_index": t.order_index, "title": t.title,
            "description": t.description or "", "starter_code": t.starter_code or "",
            "ai_criteria": t.ai_criteria or "", "ai_system_prompt": t.ai_system_prompt or ""}

async def own_lesson(lesson_id: str, teacher: Teacher, db: AsyncSession) -> Lesson:
    l = (await db.execute(select(Lesson).where(Lesson.id == lesson_id))).scalar_one_or_none()
    if not l or l.teacher_id != teacher.id:
        raise HTTPException(404, "Урок не найден")
    return l

async def lesson_tasks(lesson_id: str, db: AsyncSession) -> list[Task]:
    return (await db.execute(select(Task).where(Task.lesson_id == lesson_id).order_by(Task.order_index))).scalars().all()

# ═══════════════════════════ ПЕСОЧНИЦА И AI ═══════════════════════════
def run_code(code: str) -> tuple[str, str, int]:
    started = time.perf_counter()
    try:
        p = subprocess.run([sys.executable, "-I", "-c", code], capture_output=True, text=True,
                           timeout=settings.SANDBOX_TIMEOUT, errors="replace")
        return (p.stdout or "")[:20000], (p.stderr or "")[:20000], int((time.perf_counter() - started) * 1000)
    except subprocess.TimeoutExpired:
        return "", f"Превышено время выполнения ({settings.SANDBOX_TIMEOUT} с). Проверь циклы.", int((time.perf_counter() - started) * 1000)
    except Exception as e:
        return "", f"Ошибка запуска: {e}", 0

async def ai_review(task: Task, code: str, stdout: str, stderr: str) -> dict:
    try:
        from ai_checker import check_with_ai
        r = await check_with_ai(task_description=task.description or task.title, task_criteria=task.ai_criteria or "",
                                ai_system_prompt=task.ai_system_prompt or "", student_code=code, stdout=stdout, stderr=stderr)
        get = (lambda k, d=None: r.get(k, d)) if isinstance(r, dict) else (lambda k, d=None: getattr(r, k, d))
        return {"is_correct": bool(get("is_correct", False)), "score": int(get("score", 0)),
                "feedback": str(get("feedback", "")), "reasoning": str(get("reasoning", ""))}
    except Exception as e:
        ok = not stderr.strip()
        last = stderr.strip().splitlines()[-1] if stderr.strip() else "ошибка"
        return {"is_correct": ok, "score": 90 if ok else 35,
                "feedback": "Отлично! Программа работает без ошибок. Продолжай в том же духе." if ok
                else f"Программа завершилась с ошибкой. Посмотри консоль: {last}",
                "reasoning": f"Локальная проверка (AI недоступен: {type(e).__name__})"}

async def review_background(submission_id: str):
    try:
        async with async_session() as db:
            sub = (await db.execute(select(Submission).where(Submission.id == submission_id))).scalar_one_or_none()
            if not sub:
                return
            task = (await db.execute(select(Task).where(Task.id == sub.task_id))).scalar_one_or_none()
            sess = (await db.execute(select(StudentSession).where(StudentSession.id == sub.session_id))).scalar_one_or_none()
            verdict = await ai_review(task, sub.code, sub.stdout or "", sub.stderr or "") if task else \
                {"is_correct": False, "score": 0, "feedback": "Задание удалено.", "reasoning": ""}
            db.add(AIReview(submission_id=sub.id, is_correct=verdict["is_correct"], score=verdict["score"],
                            feedback=verdict["feedback"], reasoning=verdict["reasoning"], raw_llm_response=verdict))
            sub.status = "completed"
            if sess:
                g = (await db.execute(select(Grade).where(Grade.session_id == sess.id))).scalar_one_or_none()
                if not g:
                    g = Grade(session_id=sess.id); db.add(g)
                g.ai_final_score = verdict["score"]; g.updated_at = datetime.utcnow()
                if verdict["is_correct"]:
                    tasks = await lesson_tasks(sess.lesson_id, db)
                    idx = sess.current_task_index or 0
                    if idx < len(tasks) - 1:
                        sess.current_task_index = idx + 1
                    else:
                        sess.is_completed = True
            await db.commit()
    except Exception:
        traceback.print_exc()
        try:
            async with async_session() as db:
                sub = (await db.execute(select(Submission).where(Submission.id == submission_id))).scalar_one_or_none()
                if sub:
                    sub.status = "completed"
                    db.add(AIReview(submission_id=sub.id, is_correct=False, score=0,
                                    feedback="Не удалось проверить решение. Попробуй ещё раз.", reasoning="internal error"))
                    await db.commit()
        except Exception:
            pass

# ═══════════════════════════ РОУТЫ УЧИТЕЛЯ ═══════════════════════════
teacher = APIRouter(prefix="/api/teacher", tags=["teacher"])

@teacher.post("/register")
async def register(data: RegisterIn, db: AsyncSession = Depends(get_db)):
    if (await db.execute(select(Teacher).where(Teacher.email == data.email.lower()))).scalar_one_or_none():
        raise HTTPException(400, "Учитель с таким email уже существует")
    t = Teacher(email=data.email.lower(), password_hash=hash_password(data.password), full_name=data.full_name)
    db.add(t); await db.flush()
    return {"access_token": create_access_token(t.id), "token_type": "bearer", "full_name": t.full_name}

@teacher.post("/login")
async def login(data: LoginIn, db: AsyncSession = Depends(get_db)):
    t = (await db.execute(select(Teacher).where(Teacher.email == data.email.lower()))).scalar_one_or_none()
    if not t or not verify_password(data.password, t.password_hash):
        raise HTTPException(401, "Неверный email или пароль")
    return {"access_token": create_access_token(t.id), "token_type": "bearer", "full_name": t.full_name}

@teacher.get("/me")
async def me(t: Teacher = Depends(get_current_teacher)):
    return {"id": t.id, "email": t.email, "full_name": t.full_name}

@teacher.get("/lessons")
async def list_lessons(t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    lessons = (await db.execute(select(Lesson).where(Lesson.teacher_id == t.id).order_by(Lesson.created_at.desc()))).scalars().all()
    out = []
    for l in lessons:
        tc = (await db.execute(select(func.count(Task.id)).where(Task.lesson_id == l.id))).scalar() or 0
        sc = (await db.execute(select(func.count(StudentSession.id)).where(StudentSession.lesson_id == l.id))).scalar() or 0
        out.append(lesson_dict(l, tc, sc))
    return out

@teacher.post("/lessons")
async def create_lesson(data: LessonIn, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    code = generate_access_code()
    while (await db.execute(select(Lesson).where(Lesson.access_code == code))).scalar_one_or_none():
        code = generate_access_code()
    l = Lesson(teacher_id=t.id, title=data.title, description=data.description, deadline=data.deadline, access_code=code)
    db.add(l); await db.flush()
    return lesson_dict(l)

@teacher.get("/lessons/{lesson_id}")
async def get_lesson(lesson_id: str, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    l = await own_lesson(lesson_id, t, db)
    tasks = await lesson_tasks(l.id, db)
    sessions = (await db.execute(select(StudentSession).where(StudentSession.lesson_id == l.id).order_by(StudentSession.created_at))).scalars().all()
    students = []
    for s in sessions:
        g = (await db.execute(select(Grade).where(Grade.session_id == s.id))).scalar_one_or_none()
        students.append({"session_id": s.id, "display_name": f"{s.guest_surname or ''} {s.guest_name or ''}".strip() or s.down_user_id or "Ученик",
                         "group": s.guest_group or "", "current_task_index": s.current_task_index or 0, "is_completed": bool(s.is_completed),
                         "ai_score": g.ai_final_score if g else None, "teacher_score": g.teacher_override_score if g else None,
                         "teacher_comment": g.teacher_comment if g else ""})
    return {**lesson_dict(l, len(tasks), len(sessions)), "tasks": [task_dict(x) for x in tasks], "students": students}

@teacher.patch("/lessons/{lesson_id}")
async def patch_lesson(lesson_id: str, data: LessonPatch, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    l = await own_lesson(lesson_id, t, db)
    if data.title is not None: l.title = data.title
    if data.description is not None: l.description = data.description
    if data.is_published is not None: l.is_published = data.is_published
    await db.flush()
    return lesson_dict(l)

@teacher.patch("/lessons/{lesson_id}/publish")
async def publish_lesson(lesson_id: str, data: LessonPatch, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    l = await own_lesson(lesson_id, t, db)
    l.is_published = True if data.is_published is None else data.is_published
    await db.flush()
    return lesson_dict(l)

@teacher.delete("/lessons/{lesson_id}")
async def delete_lesson(lesson_id: str, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    l = await own_lesson(lesson_id, t, db)
    await db.execute(delete(Task).where(Task.lesson_id == l.id))
    await db.delete(l)
    return {"ok": True}

@teacher.post("/lessons/{lesson_id}/tasks")
async def create_task(lesson_id: str, data: TaskIn, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    await own_lesson(lesson_id, t, db)
    mx = (await db.execute(select(func.max(Task.order_index)).where(Task.lesson_id == lesson_id))).scalar() or 0
    task = Task(lesson_id=lesson_id, order_index=data.order_index if data.order_index != 99 else mx + 1,
                title=data.title, description=data.description, starter_code=data.starter_code,
                ai_criteria=data.ai_criteria, ai_system_prompt=data.ai_system_prompt)
    db.add(task); await db.flush()
    return task_dict(task)

@teacher.patch("/tasks/{task_id}")
async def patch_task(task_id: str, data: TaskPatch, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    task = (await db.execute(select(Task).where(Task.id == task_id))).scalar_one_or_none()
    if not task: raise HTTPException(404, "Задание не найдено")
    await own_lesson(task.lesson_id, t, db)
    for f in ("title", "description", "starter_code", "ai_criteria", "ai_system_prompt", "order_index"):
        v = getattr(data, f)
        if v is not None: setattr(task, f, v)
    await db.flush()
    return task_dict(task)

@teacher.delete("/tasks/{task_id}")
async def delete_task(task_id: str, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    task = (await db.execute(select(Task).where(Task.id == task_id))).scalar_one_or_none()
    if not task: raise HTTPException(404, "Задание не найдено")
    await own_lesson(task.lesson_id, t, db)
    await db.delete(task)
    return {"ok": True}

@teacher.patch("/sessions/{session_id}/grade")
async def override_grade(session_id: str, data: GradeIn, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    s = (await db.execute(select(StudentSession).where(StudentSession.id == session_id))).scalar_one_or_none()
    if not s: raise HTTPException(404, "Сессия не найдена")
    await own_lesson(s.lesson_id, t, db)
    g = (await db.execute(select(Grade).where(Grade.session_id == s.id))).scalar_one_or_none()
    if not g:
        g = Grade(session_id=s.id); db.add(g)
    g.teacher_override_score = data.score; g.teacher_comment = data.comment
    g.status = "reviewed"; g.updated_at = datetime.utcnow()
    await db.flush()
    return {"ok": True, "score": data.score}

@teacher.get("/lessons/{lesson_id}/export")
async def export_lesson(lesson_id: str, t: Teacher = Depends(get_current_teacher), db: AsyncSession = Depends(get_db)):
    l = await own_lesson(lesson_id, t, db)
    sessions = (await db.execute(select(StudentSession).where(StudentSession.lesson_id == l.id))).scalars().all()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for s in sessions:
            subs = (await db.execute(select(Submission).where(Submission.session_id == s.id).order_by(Submission.created_at))).scalars().all()
            name = (f"{s.guest_surname or 'student'}_{s.guest_name or ''}").strip("_") or s.id[:8]
            for i, sub in enumerate(subs, 1):
                z.writestr(f"{name}/task_{i:02d}.py", sub.code or "")
            g = (await db.execute(select(Grade).where(Grade.session_id == s.id))).scalar_one_or_none()
            score = g.teacher_override_score if g and g.teacher_override_score is not None else (g.ai_final_score if g else None)
            z.writestr(f"{name}/info.txt", f"Ученик: {name}\nГруппа: {s.guest_group or '-'}\nОценка: {score if score is not None else '-'}\nЗавершён: {bool(s.is_completed)}\n")
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": f'attachment; filename="{l.access_code}_solutions.zip"'})

# ═══════════════════════════ РОУТЫ УЧЕНИКА ═══════════════════════════
student = APIRouter(prefix="/api/student", tags=["student"])

def bearer(authorization: str | None) -> str:
    if not authorization: raise HTTPException(401, "Требуется токен сессии")
    parts = authorization.split()
    return parts[1] if len(parts) == 2 and parts[0].lower() == "bearer" else authorization.strip()

async def session_by_token(token: str, db: AsyncSession) -> StudentSession:
    s = (await db.execute(select(StudentSession).where(StudentSession.session_token == token))).scalar_one_or_none()
    if not s: raise HTTPException(401, "Сессия не найдена. Войди на урок заново.")
    return s

@student.post("/join")
async def join(data: JoinIn, db: AsyncSession = Depends(get_db)):
    lesson = (await db.execute(select(Lesson).where(Lesson.access_code == data.access_code.strip().upper()))).scalar_one_or_none()
    if not lesson: raise HTTPException(404, "Урок не найден. Проверь код.")
    if not lesson.is_published: raise HTTPException(403, "Урок ещё не опубликован учителем.")
    down = await verify_down_token(data.down_token) if data.down_token else None
    token = generate_session_token()
    s = StudentSession(lesson_id=lesson.id, down_user_id=down["user_id"] if down else None,
                       guest_surname=(down["surname"] if down else data.surname) or data.surname,
                       guest_name=(down["name"] if down else data.name) or data.name,
                       guest_group=(down["group"] if down else data.group) or data.group,
                       session_token=token, current_task_index=0)
    db.add(s); await db.flush()
    return {"session_token": token, "lesson_title": lesson.title, "current_task_index": 0,
            "is_guest": down is None, "student_display_name": f"{s.guest_surname or ''} {s.guest_name or ''}".strip() or "Ученик"}

@student.get("/current-task")
async def current_task(authorization: str | None = Header(None), db: AsyncSession = Depends(get_db)):
    s = await session_by_token(bearer(authorization), db)
    tasks = await lesson_tasks(s.lesson_id, db)
    if not tasks: raise HTTPException(404, "В уроке пока нет заданий. Учитель добавит их в панели урока.")
    idx = min(s.current_task_index or 0, len(tasks) - 1)
    t = tasks[idx]
    return {"id": t.id, "order_index": t.order_index, "title": t.title, "description": t.description or "",
            "starter_code": t.starter_code or "", "total_tasks": len(tasks), "index": idx, "completed": bool(s.is_completed)}

@student.post("/execute")
async def execute(data: CodeIn, authorization: str | None = Header(None), db: AsyncSession = Depends(get_db)):
    await session_by_token(bearer(authorization), db)
    stdout, stderr, ms = run_code(data.code)
    return {"stdout": stdout, "stderr": stderr, "execution_time_ms": ms}

@student.post("/submit")
async def submit(data: CodeIn, authorization: str | None = Header(None), db: AsyncSession = Depends(get_db)):
    s = await session_by_token(bearer(authorization), db)
    tasks = await lesson_tasks(s.lesson_id, db)
    if not tasks: raise HTTPException(404, "В уроке нет заданий.")
    idx = min(s.current_task_index or 0, len(tasks) - 1)
    stdout, stderr, ms = run_code(data.code)
    sub = Submission(session_id=s.id, task_id=tasks[idx].id, code=data.code, stdout=stdout, stderr=stderr,
                     execution_time_ms=ms, status="checking")
    db.add(sub); await db.flush()
    sub_id = sub.id
    await db.commit()
    asyncio.create_task(review_background(sub_id))
    return {"submission_id": sub_id, "status": "checking"}

@student.get("/submission/{submission_id}")
async def submission_status(submission_id: str, authorization: str | None = Header(None), db: AsyncSession = Depends(get_db)):
    s = await session_by_token(bearer(authorization), db)
    sub = (await db.execute(select(Submission).where(Submission.id == submission_id, Submission.session_id == s.id))).scalar_one_or_none()
    if not sub: raise HTTPException(404, "Отправка не найдена")
    rev = (await db.execute(select(AIReview).where(AIReview.submission_id == sub.id))).scalar_one_or_none()
    return {"id": sub.id, "status": sub.status, "stdout": sub.stdout or "", "stderr": sub.stderr or "",
            "execution_time_ms": sub.execution_time_ms or 0,
            "review": {"is_correct": bool(rev.is_correct), "score": rev.score, "feedback": rev.feedback,
                       "reasoning": rev.reasoning or ""} if rev else None}

# ═══════════════════════════ ПРИЛОЖЕНИЕ ═══════════════════════════
async def seed_demo():
    async with async_session() as db:
        if ((await db.execute(select(func.count(Teacher.id)))).scalar() or 0) > 0:
            return
        t = Teacher(email="demo@edudown.pro", password_hash=hash_password("demo1234"), full_name="Демо Учитель")
        db.add(t); await db.flush()
        l1 = Lesson(teacher_id=t.id, title="Python: первые шаги", description="Переменные, вывод и арифметика. Три короткие задачи.",
                    access_code=generate_access_code(), is_published=True)
        l2 = Lesson(teacher_id=t.id, title="Циклы и условия", description="Черновик урока: for, while, if.",
                    access_code=generate_access_code(), is_published=False)
        db.add_all([l1, l2]); await db.flush()
        db.add_all([
            Task(lesson_id=l1.id, order_index=1, title="Привет, мир!", description="Выведи на экран строку: Привет, мир!",
                 starter_code="# Напиши свой код здесь\n", ai_criteria="Программа должна вывести строку 'Привет, мир!' через print."),
            Task(lesson_id=l1.id, order_index=2, title="Сумма двух чисел", description="Создай переменные a = 7 и b = 5, выведи их сумму.",
                 starter_code="a = 7\nb = 5\n# выведи сумму\n", ai_criteria="Вывод должен содержать число 12."),
            Task(lesson_id=l1.id, order_index=3, title="Площадь прямоугольника", description="Стороны 4 и 6. Выведи площадь.",
                 starter_code="", ai_criteria="Вывод должен содержать число 24."),
            Task(lesson_id=l2.id, order_index=1, title="Чётные числа", description="Выведи все чётные числа от 1 до 10.",
                 starter_code="", ai_criteria="Вывод: 2 4 6 8 10."),
            Task(lesson_id=l2.id, order_index=2, title="Таблица умножения", description="Выведи таблицу умножения на 3 от 1 до 5.",
                 starter_code="", ai_criteria="Вывод содержит 3, 6, 9, 12, 15."),
        ])
        await db.commit()
        print(f"[EduDown] Демо-доступ: demo@edudown.pro / demo1234 | код урока: {l1.access_code}")

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    await seed_demo()
    print("[EduDown] Запущено. БД инициализирована.")
    yield

app = FastAPI(title="EduDown Pro API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    traceback.print_exc()
    headers = {}
    origin = request.headers.get("origin")
    if origin:
        headers["Access-Control-Allow-Origin"] = origin
        headers["Access-Control-Allow-Credentials"] = "true"
    return JSONResponse(status_code=500, content={"detail": f"{type(exc).__name__}: {exc}"}, headers=headers)

app.include_router(teacher)
app.include_router(student)

@app.get("/")
async def root():
    return {"service": "EduDown Pro", "docs": "/docs", "health": "/health"}

@app.get("/health")
async def health():
    return {"status": "ok", "service": "EduDown Pro"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8001, reload=True, log_level="info")
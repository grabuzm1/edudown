from pathlib import Path
from pydantic_settings import BaseSettings

_ENV_PATH = Path(__file__).resolve().parent / ".env"  # ВСЕГДА ищем .env рядом с config.py

class Settings(BaseSettings):
    DATABASE_URL: str = "sqlite+aiosqlite:///./edu_platform.db"
    DEBUG: bool = True
    SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION_USE_OPENSSL_RAND_HEX_32"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24

    AI_PROVIDER: str = "auto"
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-2.5-flash"
    GEMINI_BASE_URL: str = ""
    OPENAI_API_KEY: str = ""
    OPENAI_BASE_URL: str = "https://openrouter.ai/api/v1"
    OPENAI_MODEL: str = "google/gemini-2.0-flash-001"
    AI_TIMEOUT: int = 45

    DOWN_API_URL: str = "https://imdown.pro"
    DOWN_SHARED_SECRET: str = ""
    SANDBOX_TIMEOUT: int = 5

    class Config:
        env_file = str(_ENV_PATH)   # абсолютный путь — работает при любом cwd
        extra = "ignore"

# БЕЗ lru_cache — чтобы после правки .env не нужен был полный рестарт процесса
def get_settings() -> Settings:
    return Settings()
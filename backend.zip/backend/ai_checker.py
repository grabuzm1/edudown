import json, re, time
import httpx
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from pydantic import BaseModel
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from config import get_settings
from database import get_db
from models import Lesson, Task, Teacher

settings = get_settings()
_bearer = HTTPBearer(auto_error=False)
_cache = {"ts": 0.0, "ok": False, "provider": None, "model": None, "error": None}
GEMINI_MODELS = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-flash-latest", "gemini-1.5-flash"]

def _gkey(): return (settings.GEMINI_API_KEY or "").strip()
def _okey(): return (settings.OPENAI_API_KEY or "").strip()

def _parse(text: str):
    text = re.sub(r"^```(?:json)?\s*", "", text.strip())
    text = re.sub(r"\s*```$", "", text)
    try: return json.loads(text)
    except Exception: pass
    for op in ("[", "{"):
        i = text.find(op)
        if i >= 0:
            try: return json.JSONDecoder().raw_decode(text[i:])[0]
            except Exception: continue
    raise RuntimeError(f"модель вернула не-JSON: {text[:160]}")

async def _gemini(prompt: str, temp: float, json_mode: bool):
    key = _gkey()
    if not key: raise RuntimeError("GEMINI_API_KEY не задан")
    bases = [b for b in [settings.GEMINI_BASE_URL.rstrip("/"), "https://generativelanguage.googleapis.com"] if b]
    models = [m for m in dict.fromkeys([settings.GEMINI_MODEL, *GEMINI_MODELS]) if m]
    errs = []
    async with httpx.AsyncClient(timeout=float(settings.AI_TIMEOUT)) as c:
        for base in bases:
            for ver in ("v1beta", "v1"):
                for m in models:
                    body = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": temp}}
                    if json_mode: body["generationConfig"]["responseMimeType"] = "application/json"
                    try:
                        r = await c.post(f"{base}/{ver}/models/{m}:generateContent",
                                         headers={"x-goog-api-key": key, "Content-Type": "application/json"}, json=body)
                    except Exception as e:
                        errs.append(f"{type(e).__name__}: {e}"); continue
                    if r.status_code == 404:
                        errs.append(f"{m}: 404"); continue
                    if r.status_code != 200:
                        msg = r.text[:200]
                        try: msg = r.json().get("error", {}).get("message", msg)
                        except Exception: pass
                        errs.append(f"{m}: HTTP {r.status_code} {msg}")
                        if r.status_code in (400, 403) and ("location" in msg.lower() or "api key" in msg.lower() or "permission" in msg.lower()):
                            raise RuntimeError(f"Gemini отказал: {msg}")
                        continue
                    parts = r.json().get("candidates", [{}])[0].get("content", {}).get("parts", [])
                    text = "".join(p.get("text", "") for p in parts)
                    if not text.strip(): errs.append(f"{m}: пустой ответ"); continue
                    return text, f"gemini:{m}"
    raise RuntimeError("Gemini недоступен → " + " | ".join(errs[-3:]))

async def _openai(prompt: str, temp: float, json_mode: bool):
    key = _okey()
    if not key: raise RuntimeError("OPENAI_API_KEY не задан")
    body = {"model": settings.OPENAI_MODEL, "messages": [{"role": "user", "content": prompt}], "temperature": temp}
    if json_mode: body["response_format"] = {"type": "json_object"}
    async with httpx.AsyncClient(timeout=float(settings.AI_TIMEOUT)) as c:
        r = await c.post(f"{settings.OPENAI_BASE_URL.rstrip('/')}/chat/completions",
                         headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, json=body)
        if r.status_code != 200:
            msg = r.text[:200]
            try: msg = r.json().get("error", {}).get("message", msg)
            except Exception: pass
            raise RuntimeError(f"шлюз HTTP {r.status_code}: {msg}")
        text = r.json()["choices"][0]["message"]["content"] or ""
        if not text.strip(): raise RuntimeError("шлюз вернул пустой ответ")
        return text, f"openai:{settings.OPENAI_MODEL}"

async def ask(prompt: str, temp=0.4, json_mode=True):
    order = {"gemini": [_gemini], "openai": [_openai], "local": [],
             "auto": [_gemini, _openai]}.get(settings.AI_PROVIDER.lower(), [_gemini, _openai])
    if not order: raise RuntimeError("AI_PROVIDER=local — нейросеть отключена")
    errs = []
    for fn in order:
        try: return await fn(prompt, temp, json_mode)
        except Exception as e: errs.append(str(e))
    raise RuntimeError(" | ".join(errs))
# ── локальный верификатор: строгий, знает русские синонимы ──
NUM = re.compile(r"-?\d+(?:[.,]\d+)?")
STR = re.compile(r"['\"«]([^'\"»]{2,60})['\"»]")
SEQ = re.compile(r"(?:-?\d+[ \t]+){2,}-?\d+")

_CONSTRUCT_RULES = [
    ("input",      r"\binput\b|введ[иы]|счит[ыв]|получ[аи]|от пользователя|из консоли", r"\binput\s*\("),
    ("print",      r"\bprint\b|вывед[иы]|на экран|покаж[еи]|отобраз[иы]|распечат",        r"\bprint\s*\("),
    ("for",        r"\bfor\b|цикл[аи]? ?for|перебер[еи]",                                  r"\bfor\b"),
    ("while",      r"\bwhile\b|цикл while|пока",                                            r"\bwhile\b"),
    ("if",         r"\bif\b|услов[ие]|если|ветвл",                                          r"\bif\b"),
    ("def",        r"\bdef\b|функци[ия]|оболочк",                                           r"\bdef\s+\w+"),
    ("range",      r"\brange\b",                                                            r"\brange\s*\("),
    ("int",        r"\bint\b|целое число|преобраз[уув] в int",                              r"\bint\s*\("),
    ("float",      r"\bfloat\b|дробн",                                                      r"\bfloat\s*\("),
    ("sum",        r"\bsum\b|сумм[аы]",                                                     r"\bsum\s*\(|\+=|\+=\s"),
    ("len",        r"\blen\b|длин[аы]|кол-во элементов",                                    r"\blen\s*\("),
    ("list",       r"\blist\b|списк[аи]|массив",                                            r"\[|\blist\s*\("),
    ("dict",       r"\bdict\b|словар[ья]",                                                  r"\{|\bdict\s*\("),
    ("f-string",   r"\bf['\"]|f-стро[кка]|интерполяция",                                    r"f['\"]"),
]

def local_review(description: str, criteria: str, code: str, stdout: str, stderr: str, ai_error: str = "") -> dict:
    out = " ".join((stdout or "").split())
    src = (criteria or "").strip() or (description or "").strip()
    blob = (criteria or "") + " " + (description or "")

    if (stderr or "").strip():
        last = stderr.strip().splitlines()[-1]
        return {"is_correct": False, "score": 15, "has_checks": True,
                "feedback": f"Программа падает: {last}. Исправь ошибку — без рабочего запуска проверка не проводится.",
                "reasoning": f"RuntimeError: {last}" + (f" | AI: {ai_error}" if ai_error else "")}

    checks: list[tuple[str, bool]] = []

    for n in dict.fromkeys(NUM.findall(src)):
        checks.append((f"вывод содержит {n}",
                       re.search(rf"(?<![\d.,]){re.escape(n)}(?![\d.,])", out) is not None))
    for s in dict.fromkeys(STR.findall(src)):
        checks.append((f"вывод содержит «{s}»", s.lower() in out.lower()))
    for sq in SEQ.findall(src):
        checks.append((f"последовательность {' '.join(sq.split())}", " ".join(sq.split()) in out))

    low = blob.lower()
    for name, rx_text, rx_code in _CONSTRUCT_RULES:
        if re.search(rx_text, low, re.IGNORECASE):
            checks.append((f"код использует {name}", re.search(rx_code, code) is not None))

    if not checks:
        return {"is_correct": False, "score": 0, "has_checks": False,
                "feedback": ("Не удалось извлечь конкретные проверки из критериев задания. "
                             "Учитель должен уточнить ожидаемый вывод или обязательные конструкции — "
                             "пока решение не засчитывается автоматически."),
                "reasoning": "Критерии не машинно-проверяемы" + (f" | AI: {ai_error}" if ai_error else "")}

    missing = [label for label, ok in checks if not ok]
    passed = len(checks) - len(missing)
    if not missing:
        return {"is_correct": True, "score": 100, "has_checks": True,
                "feedback": "Все проверки по условию пройдены: " + "; ".join(l for l, _ in checks) + ". Отличная работа!",
                "reasoning": "Локальный верификатор: " + "; ".join(f"{l}=OK" for l, _ in checks) + (f" | AI: {ai_error}" if ai_error else "")}

    score = max(5, int(100 * passed / len(checks)) - 15)
    return {"is_correct": False, "score": score, "has_checks": True,
            "feedback": f"Программа запустилась, но условие НЕ выполнено полностью. Не хватает: {'; '.join(missing)}. "
                        f"Сверь вывод и код с текстом задания.",
            "reasoning": "Локальный верификатор: " + "; ".join(f"{l}={'OK' if ok else 'НЕТ'}" for l, ok in checks) + (f" | AI: {ai_error}" if ai_error else "")}


async def check_with_ai(task_description: str, task_criteria: str, ai_system_prompt: str,
                        student_code: str, stdout: str, stderr: str) -> dict:
    persona = (ai_system_prompt or "").strip() or "Ты строгий учитель информатики. Пиши по-русски на «ты»."
    prompt = f"""{persona}

ЗАДАНИЕ ДЛЯ УЧЕНИКА:
{task_description}

КРИТЕРИИ ПРАВИЛЬНОСТИ (единственный источник истины):
{task_criteria or 'Решение выполняет условие и работает без ошибок.'}

КОД УЧЕНИКА:
```python
{student_code}
STDOUT:
{stdout or '(пусто)'}

STDERR:
{stderr or '(пусто)'}

ИНСТРУКЦИЯ ОЦЕНКИ (строго следуй):
1. Выпиши ВСЕ требования из критериев списком (каждое требование отдельным пунктом).
2. Для каждого требования проверь его по ФАКТУ: по коду ученика и по реальному STDOUT/STDERR.
3. НЕ засчитывай решение только потому, что программа запустилась без ошибок.
   Пример неправильного засчёта: задание «считай сумму через input и выведи её», а ученик
   написал print("Привет") — программа работает, но НЕ выполняет задание → is_correct=false.
4. Если в задании требуется ввод — в коде ОБЯЗАТЕЛЬНО должен быть вызов input().
   Если требуется вывод — должен быть print(). Если требуется цикл/условие/функция — соответствующие конструкции.
5. Если STDOUT не содержит того, что требует задание (числа, строки, последовательности) — is_correct=false.
6. is_correct=true ТОЛЬКО если выполнены ВСЕ требования без исключений.

Верни СТРОГО JSON (без markdown, без пояснений вокруг):
{{
  "requirements": ["требование 1", "требование 2", ...],
  "checks": [{{"requirement": "...", "passed": true/false, "evidence": "что именно в коде/выводе это подтверждает или опровергает"}}],
  "is_correct": true/false,
  "score": 0-100,
  "feedback": "2-4 предложения ученику: что верно, что конкретно исправить, подсказка как",
  "reasoning": "краткое обоснование для учителя"
}}
Шкала: 100 = всё верно; 60-80 = работает, но есть недочёты по критериям; 30-50 = частично; 0-20 = не выполнено/падает."""
    gem_verdict["is_correct"] = False
    gem_verdict["score"] = min(gem_verdict["score"], local["score"])
    gem_verdict["feedback"] = (local["feedback"] +
                               " (ИИ-оценщик хотел засчитать, но формальные проверки по критериям не пройдены.)")
    gem_verdict["reasoning"] = (gem_verdict["reasoning"] + " | " + local["reasoning"]).strip()


gem_verdict["reasoning"] = (gem_verdict["reasoning"] + f" [провайдер: {provider}]").strip()
return gem_verdict


async def generate_tasks(brief: str, count: int = 3, level: str = "начинающий") -> list[dict]:
    count = max(1, min(6, int(count)))
    prompt = f"""Ты методист по Python для школьников. Учитель просит: «{brief}». Уровень: {level}.
    Сгенерируй ровно {count} заданий от простого к сложному.
    Верни СТРОГО JSON-массив: [{{"title": "до 60 символов", "description": "понятный ученику текст: что сделать, пример вывода, ограничения; 3-6 предложений", "starter_code": "стартовый код с комментариями или пустая строка", "ai_criteria": "ТОЧНО проверяемое условие: конкретный ожидаемый вывод (числа/строки/последовательность) и обязательные конструкции"}}]
    Критерии обязаны содержать конкретный ожидаемый вывод, чтобы автопроверка работала. Все тексты на русском. Решения в 5-15 строк."""
    text, _ = await ask(prompt, 0.7)
    arr = _parse(text)
    if isinstance(arr, dict): arr = arr.get("tasks", [])
    if not isinstance(arr, list) or not arr: raise RuntimeError("модель не вернула список заданий")
    out = []
    for i, it in enumerate(arr[:count], 1):
        if isinstance(it, dict):
            out.append(
                {"title": str(it.get("title", f"Задание {i}"))[:120], "description": str(it.get("description", "")),
                 "starter_code": str(it.get("starter_code", "")), "ai_criteria": str(it.get("ai_criteria", "")),
                 "order_index": i})
    if not out: raise RuntimeError("модель вернула пустые задания")
    return out


async def status() -> dict:
    now = time.time()
    hint = (_gkey()[:6] + "…") if _gkey() else ((_okey()[:6] + "…") if _okey() else "")
    if now - _cache["ts"] < 10:
        return {"configured": bool(_gkey() or _okey()), "ok": _cache["ok"],
                "provider": _cache["provider"], "model": _cache["model"],
                "error": _cache["error"], "key_hint": hint}
    ok, provider, error = False, None, None
    try:
        _t, provider = await ask("Ответь одним словом: OK", 0.0, False);
        ok = True
    except Exception as e:
        error = str(e)
    _cache.update(ts=now, ok=ok, provider=provider, model=provider, error=error)
    return {"configured": bool(_gkey() or _okey()), "ok": ok,
            "provider": provider, "model": provider, "error": error, "key_hint": hint}
# ── схемы запросов ──
class AiIn(BaseModel): brief: str; count: int = 3; level: str = "начинающий"
class SelfTestIn(BaseModel): task_id: str = ""; code: str = "print('Привет, мир!')"


async def _teacher(cr: HTTPAuthorizationCredentials | None = Depends(_bearer),
                   db: AsyncSession = Depends(get_db)) -> Teacher:
    if cr is None: raise HTTPException(401, "Требуется авторизация учителя")
    try:
        p = jwt.decode(cr.credentials, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        tid = p.get("sub")
        if not tid or p.get("type") != "teacher": raise HTTPException(401, "Невалидный токен")
    except JWTError: raise HTTPException(401, "Невалидный токен")
    t = (await db.execute(select(Teacher).where(Teacher.id == tid))).scalar_one_or_none()
    if not t: raise HTTPException(401, "Учитель не найден")
    return t


router = APIRouter(prefix="/api/teacher", tags=["teacher-ai"])


@router.get("/ai-status")
async def ai_status(t: Teacher = Depends(_teacher)):
    return await status()


@router.post("/ai-selftest")
async def ai_selftest(d: SelfTestIn, t: Teacher = Depends(_teacher), db: AsyncSession = Depends(get_db)):
    task = (await db.execute(select(Task).where(Task.id == d.task_id))).scalar_one_or_none() if d.task_id else None
    desc = task.description if task else "Выведи на экран строку: Привет, мир!"
    crit = task.ai_criteria if task else "Программа должна вывести строку 'Привет, мир!' через print."
    import subprocess, sys as _sys
    try:
        p = subprocess.run([_sys.executable, "-I", "-c", d.code], capture_output=True, text=True,
                           timeout=settings.SANDBOX_TIMEOUT, errors="replace")
        out, err = p.stdout or "", p.stderr or ""
    except Exception as e:
        out, err = "", str(e)
    verdict = await check_with_ai(desc, crit, task.ai_system_prompt if task else "", d.code, out, err)
    return {"stdout": out, "stderr": err, "verdict": verdict, "status": await status()}


@router.post("/ai-preview")
async def ai_preview(d: AiIn, t: Teacher = Depends(_teacher)):
    if not d.brief.strip(): raise HTTPException(400, "Опиши, какие задания нужны")
    try: return {"tasks": await generate_tasks(d.brief, d.count, d.level)}
    except Exception as e: raise HTTPException(502, f"AI не смог сгенерировать задания: {e}")


@router.post("/lessons/{lid}/ai-tasks")
async def ai_tasks(lid: str, d: AiIn, t: Teacher = Depends(_teacher), db: AsyncSession = Depends(get_db)):
    l = (await db.execute(select(Lesson).where(Lesson.id == lid))).scalar_one_or_none()
    if not l or l.teacher_id != t.id: raise HTTPException(404, "Урок не найден")
    if not d.brief.strip(): raise HTTPException(400, "Опиши, какие задания нужны")
    try: drafts = await generate_tasks(d.brief, d.count, d.level)
    except Exception as e: raise HTTPException(502, f"AI не смог сгенерировать задания: {e}")
    mx = (await db.execute(select(func.max(Task.order_index)).where(Task.lesson_id == l.id))).scalar() or 0
    created = []
    for i, dr in enumerate(drafts, 1):
        tk = Task(lesson_id=l.id, order_index=mx + i, title=dr["title"], description=dr["description"],
                  starter_code=dr["starter_code"], ai_criteria=dr["ai_criteria"])
        db.add(tk); await db.flush()
        created.append({"id": tk.id, "order_index": tk.order_index, "title": tk.title,
                        "description": tk.description, "starter_code": tk.starter_code, "ai_criteria": tk.ai_criteria})
    return {"tasks": created}
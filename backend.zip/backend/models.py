import uuid
from datetime import datetime
from sqlalchemy import (
    Column, String, Text, Integer, Boolean, DateTime, ForeignKey, JSON
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from database import Base


def new_uuid() -> str:
    return str(uuid.uuid4())


class Teacher(Base):
    __tablename__ = "teachers"

    id = Column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    lessons = relationship("Lesson", back_populates="teacher", cascade="all, delete-orphan")


class Lesson(Base):
    __tablename__ = "lessons"

    id = Column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    teacher_id = Column(UUID(as_uuid=False), ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, default="")
    access_code = Column(String(50), unique=True, nullable=False, index=True)
    deadline = Column(DateTime, nullable=True)
    is_published = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    teacher = relationship("Teacher", back_populates="lessons")
    tasks = relationship("Task", back_populates="lesson", cascade="all, delete-orphan",
                         order_by="Task.order_index")
    sessions = relationship("StudentSession", back_populates="lesson", cascade="all, delete-orphan")


class Task(Base):
    __tablename__ = "tasks"

    id = Column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    lesson_id = Column(UUID(as_uuid=False), ForeignKey("lessons.id", ondelete="CASCADE"), nullable=False)
    order_index = Column(Integer, nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    starter_code = Column(Text, default="")
    ai_criteria = Column(Text, nullable=False)  # Что считать правильным решением
    ai_system_prompt = Column(Text, default="Ты строгий, но доброжелательный учитель информатики.")
    created_at = Column(DateTime, default=datetime.utcnow)

    lesson = relationship("Lesson", back_populates="tasks")
    submissions = relationship("Submission", back_populates="task", cascade="all, delete-orphan")


class StudentSession(Base):
    __tablename__ = "student_sessions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    lesson_id = Column(UUID(as_uuid=False), ForeignKey("lessons.id", ondelete="CASCADE"), nullable=False)

    # Гибридная идентификация: Down ID или гость
    down_user_id = Column(String(100), nullable=True, index=True)  # ID из imdown.pro
    guest_surname = Column(String(100), nullable=True)
    guest_name = Column(String(100), nullable=True)
    guest_group = Column(String(50), nullable=True)

    session_token = Column(String(255), unique=True, nullable=False, index=True)
    current_task_index = Column(Integer, default=0)
    is_completed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    lesson = relationship("Lesson", back_populates="sessions")
    submissions = relationship("Submission", back_populates="session", cascade="all, delete-orphan")
    grade = relationship("Grade", back_populates="session", uselist=False, cascade="all, delete-orphan")


class Submission(Base):
    __tablename__ = "submissions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    session_id = Column(UUID(as_uuid=False), ForeignKey("student_sessions.id", ondelete="CASCADE"), nullable=False)
    task_id = Column(UUID(as_uuid=False), ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False)
    code = Column(Text, nullable=False)
    stdout = Column(Text, default="")
    stderr = Column(Text, default="")
    execution_time_ms = Column(Integer, default=0)
    status = Column(String(50), default="pending")  # pending, ai_reviewing, completed, manual_review
    created_at = Column(DateTime, default=datetime.utcnow)

    session = relationship("StudentSession", back_populates="submissions")
    task = relationship("Task", back_populates="submissions")
    ai_review = relationship("AIReview", back_populates="submission", uselist=False, cascade="all, delete-orphan")


class AIReview(Base):
    __tablename__ = "ai_reviews"

    id = Column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    submission_id = Column(UUID(as_uuid=False), ForeignKey("submissions.id", ondelete="CASCADE"), unique=True,
                           nullable=False)
    is_correct = Column(Boolean, nullable=False)
    score = Column(Integer, nullable=False)
    feedback = Column(Text, nullable=False)
    reasoning = Column(Text, default="")
    raw_llm_response = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    submission = relationship("Submission", back_populates="ai_review")


class Grade(Base):
    __tablename__ = "grades"

    id = Column(UUID(as_uuid=False), primary_key=True, default=new_uuid)
    session_id = Column(UUID(as_uuid=False), ForeignKey("student_sessions.id", ondelete="CASCADE"), unique=True,
                        nullable=False)
    ai_final_score = Column(Integer, nullable=True)
    teacher_override_score = Column(Integer, nullable=True)
    teacher_comment = Column(Text, default="")
    status = Column(String(50), default="ai_graded")  # ai_graded, teacher_reviewed
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    session = relationship("StudentSession", back_populates="grade")